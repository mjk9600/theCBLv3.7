@extends('layout')
@section('title', 'The CBL | Dashboard')
@section('content')
<!DOCTYPE html>
<html>
    <head>
        <title>TheCBL</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href={{url('css/bootstrap.css')}}>
        <link rel="stylesheet" href={{url('css/layout.css')}}>
        <link rel="stylesheet" href={{url('css/teamregistration.css')}}>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" />
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
     <script   src={{url('js/bootstrap.bundle.js')}}></script>

    </head>
    <body >
    <h1 class="text-center">Team Registration</h1>
    <hr style="width: 50%;margin-left: 25%;margin-top: -1vh;border: 2px solid white;color: white;">
    <form action="#" method="get">
    <div class="d-flex justify-content-center flex-row wrapExtra" >
        <div class="d-flex justify-content-center mx-5 flex-column px-5 wrapExtra">
            <ol>
                <li><label for="first-name" class="form-label">First Name * </label></li>
                <li><input type="text" name="first-name" class="form-control" placeholder="Enter First Name" required/></li>
            </ol>
            <ol>
                <li><label for="middle-name" class="form-label">Middle Name </label></li>
                <li><input type="text" name="middle-name" class="form-control" placeholder="Enter Middle Name" required/></li>
            </ol>
            <ol>
                <li><label for="last-name" class="form-label">Last Name *</label></li>
                <li><input type="text" name="last-name" class="form-control" placeholder="Enter Last Name" required/></li>
            </ol>
            <ol>
                <li><label for="last-name" class="form-label">Last Name *</label></li>
                <li><input type="text" name="last-name" class="form-control" placeholder="Enter Last Name" required/></li>
            </ol>
            <ol>
                <li class="d-flex justify-content-between mt-3  ">
                    <button class="btn btn-light ">Cancel</button>
                    <button class="btn btn-light  ms-1" type="submit">Submit</button>
                </li>
            </ol>
        </div>
        <div class="d-flex justify-content-end flex-column" style="border-radius:5px ;background-color: gray;">
            <div class="m-0">
           
                <div class="form-group input-group">
                    <input type="text" placeholder="Search Player by Name,Email,Mobile" id="search" class="form-control " style="border-radius: 10px;" onchange="onValidation()">
                    <i class="input-group-text fa-solid fa-search mt-2" style="cursor: pointer; display: block;border-radius: 10px;"></i>
                </div>
                <!-- <hr style="color: black;"> -->
            </div>
            <div class="m-auto table-responsive"  > 
              <table class="table table-light m-1 tableBorder " style="width: 98%;" id="sampleTbl">
                <thead>
                    <tr>
                        <th>Sr.No</th>
                        <th>Profile</th>
                        <th>Player </th>
                        <th>Position</th>
                        <th>Status</th>
                        <th>Change</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>parth</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>rajan</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Nisarg</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                    </tr>
                    <tr>
                        <td>8</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                    </tr>
                    <tr>
                        <td>9</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                    </tr>
                    <tr>
                        <td>10</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                        <td>asd</td>
                    </tr>
              </tbody>
              </table>

            </div>       
        </div>
    </div>
    
    </form>

</body>
</html>
@endsection